package com.hzy.testbleadv;

import android.Manifest;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.ParcelUuid;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.bluetooth.le.ScanCallback;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "TestBleAdv";
    Button btnScan;
    Button btnAdvertise;
    private BluetoothAdapter mBtAdpter;
    private BluetoothManager mBtManager;
    private BluetoothLeScanner mBtLeScanner;
    private BluetoothLeAdvertiser mBtLeAdertiser;
    private static String MY_UUID = "0000F000-0000-1000-8000-00805F9B34FB";
    private Context mContext;
    private Boolean mScanning =false;
    private boolean isDeviceFound = false;
    //private BroadcastReceiver mBondBroadcastReceiver;
    private String mTargetDeviceAddress;
    private BondBroadcastReceiver mBondBroadcastReceiver = new BondBroadcastReceiver();
	private BluetoothChatService mChatService = null;

    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;
    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_main);
        initVariables();
        initViews();
        initListeners();
        initReceivers();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    private void initVariables(){
        mBtAdpter       =  BluetoothAdapter.getDefaultAdapter();
        mBtLeScanner    =  mBtAdpter.getBluetoothLeScanner();
        Log.e(TAG,""+mBtLeScanner);
        mBtLeAdertiser  =  mBtAdpter.getBluetoothLeAdvertiser();
        Log.e(TAG,""+mBtLeAdertiser);
        mChatService = new BluetoothChatService(this, mHandler);

        if (mChatService != null) {
            // Only if the state is STATE_NONE, do we know that we haven't started already
            if (mChatService.getState() == BluetoothChatService.STATE_NONE) {
                // Start the Bluetooth chat services
                mChatService.start();
            }
        }

    }
    private void initViews(){
        btnScan       = (Button) findViewById(R.id.button_scan);
        btnAdvertise = (Button) findViewById(R.id.button_advertise);
    }

    private void initListeners(){
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startBleScan();
            }
        });
        btnAdvertise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startBleAdvertiser();
            }
        });
    }

    private  void initReceivers(){
        registerBondBroadcastReceiver();
    }

    private void registerBondBroadcastReceiver() {
        IntentFilter bondFilter = new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        mContext.registerReceiver(mBondBroadcastReceiver, bondFilter);
    }


    private  void  BondTargetDevice(BluetoothDevice device){
        Log.d(TAG, "device bond state" + device.getBondState());
        final BluetoothDevice tmpDevice = device;
        if (device.getBondState() != BluetoothDevice.BOND_NONE) {

        } else {
            boolean createBondSuccess = device.createBond();
            Log.e(TAG, "设备尚未配对，开始进行配对");
        }
    }

    private  void  ConnectTargetDevice(BluetoothDevice device){
        Log.e(TAG, "device bond state" + device.getBondState());
        final BluetoothDevice tmpDevice = device;
        if (device.getBondState() != BluetoothDevice.BOND_NONE) {
		    Log.e(TAG,"设备当前已经配对，直接连接");
			//ConnectTargetDevice(device);
        } else {
            boolean createBondSuccess = device.createBond();
            // mLogg.fileInfo(TAG, "#onLeScan(): " + "Create bond : " + createBondSuccess + ".");
            Log.e(TAG, "设备尚未配对，开始进行配对");
        }
    }

    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_STATE_CHANGE:
                     Log.e(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                    switch (msg.arg1) {
                        case BluetoothChatService.STATE_CONNECTED:
                            break;
                        case BluetoothChatService.STATE_CONNECTING:
                            break;
                        case BluetoothChatService.STATE_LISTEN:
                        case BluetoothChatService.STATE_NONE:
                            break;
                    }
                    break;
                case MESSAGE_WRITE:
                    byte[] writeBuf = (byte[]) msg.obj;
                    // construct a string from the buffer
                    String writeMessage = new String(writeBuf);
                    break;
                case MESSAGE_READ:
                    byte[] readBuf = (byte[]) msg.obj;
                    // construct a string from the valid bytes in the buffer
                    String readMessage = new String(readBuf, 0, msg.arg1);
                    break;
                case MESSAGE_DEVICE_NAME:
                    // save the connected device's name
                    break;
                case MESSAGE_TOAST:
                    break;
            }
        }
    };


    class  BondBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            Log.e(TAG, "mBondBroadcastReceiver" + device);
            if (device == null) {
                return;
            }
            if (mTargetDeviceAddress != null && mTargetDeviceAddress.equals(device.getAddress())){
                int currentBondState = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothAdapter.ERROR);
                int previousBondState = intent.getIntExtra(BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE, BluetoothAdapter.ERROR);
                if(currentBondState == BluetoothDevice.BOND_BONDED && previousBondState == BluetoothDevice.BOND_BONDING) {
                    //boolean connectSuccess = ConnectTargetDevice(device);
                    Log.e(TAG,"Bonded OK, Begin Connect Devices");
					ConnectTargetDevice(device);
                }
            }
        }
    }




    ScanCallback mBleScanCallbak = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            if(result.getScanRecord().getServiceUuids() != null) {
                Log.e(TAG,"scanRecord.getDeviceName" + result.getScanRecord().getDeviceName());
                Log.e(TAG,"uuid " +result.getScanRecord().getServiceUuids());
                Log.e(TAG,"onScanResult" +result.toString());
                Log.e(TAG,"rssi  =" +result.getRssi());
                Log.e(TAG,"device.getname" +result.getDevice().getName());
                Log.e(TAG,"tx Level " +result.getScanRecord().getTxPowerLevel());
                Log.e(TAG,"bytes:length" + result.getScanRecord().getBytes().length);
                Log.e(TAG,"bytes:" +Arrays.toString(result.getScanRecord().getBytes()) );
                Log.e(TAG,"" + result.getScanRecord().getManufacturerSpecificData());

                for(ParcelUuid parcelUuid:result.getScanRecord().getServiceUuids()){
                    Log.e(TAG,"parcelUuid.toString()" + parcelUuid.toString());
                    if(parcelUuid.toString().toUpperCase().equals(MY_UUID)){
                            Log.e(TAG,"Find A Little Magic Projector Device,hahahahaha! DeviceName =" + result.getDevice().getName());
                            //此时开始连接小魔投，需要先停止扫描
                        mBtLeScanner.stopScan(mBleScanCallbak);
                        mScanning =false;
                        Log.e(TAG,"find device,Stop Le Scan ");
                        if(isDeviceFound == false){
                            isDeviceFound = true;
                            mTargetDeviceAddress = result.getDevice().getAddress();
                            Log.e(TAG,"Begin to Bond Device " + mTargetDeviceAddress);
                            BondTargetDevice(result.getDevice());
                        }
                    }
                }
            }
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            super.onBatchScanResults(results);
            Log.e(TAG,"onBatchScanResultst");
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
            Log.e(TAG,"onScanFailed:" + errorCode);
        }

    };

    AdvertiseCallback mBleAdvtiseCallBack = new  AdvertiseCallback(){

        @Override
        public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            super.onStartSuccess(settingsInEffect);
            Log.e(TAG,"start advertise ok");
        }

        @Override
        public void onStartFailure(int errorCode) {
            super.onStartFailure(errorCode);
            Log.e(TAG,"start advertise fail");
        }
    };

    private void startBleScan() {
        Log.e(TAG,"startBleScan");
        isDeviceFound = false;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.e(TAG,"stopBleScan");
                mBtLeScanner.stopScan(mBleScanCallbak);
                mScanning = false;
            }
        }, 30000);

        if(Build.VERSION.SDK_INT >=23) {
            int checkPermission = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION);

            if (checkPermission != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            }

            checkPermission = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION);

            if (checkPermission != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        }
        mScanning = true;
        mBtLeScanner.startScan(mBleScanCallbak);
    }

    private void startBleAdvertiser(){
        if(mScanning) {
            mBtLeScanner.stopScan(mBleScanCallbak);
        }
        Log.e(TAG,"start advertise");
        AdvertiseData advData =  createAdvertiseData();
        if(mBtLeAdertiser== null){
            Toast.makeText(mContext,"本机不支持发送BLE广播",Toast.LENGTH_LONG).show();
            return;
        }
        mBtLeAdertiser.startAdvertising(createAdvertiseSettings(true,0),advData,mBleAdvtiseCallBack);
    }

    public static AdvertiseData createAdvertiseData(){
        AdvertiseData.Builder    mDataBuilder = new AdvertiseData.Builder();
        mDataBuilder.addServiceUuid(ParcelUuid.fromString(MY_UUID));
        AdvertiseData mAdvertiseData = mDataBuilder.build();
        if(mAdvertiseData==null){
            Log.e(TAG,"mAdvertiseSettings == null");
        }

        return mAdvertiseData;
    }

    public static AdvertiseSettings  createAdvertiseSettings(boolean connectable, int timeoutMs ){
        AdvertiseSettings.Builder settingBuilder = new AdvertiseSettings.Builder();
        settingBuilder.setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED);
        settingBuilder.setConnectable(connectable);
        settingBuilder.setTimeout(timeoutMs);
        settingBuilder.setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH);
        AdvertiseSettings advertiseSettings  = settingBuilder.build();

        return advertiseSettings;
    }
}
